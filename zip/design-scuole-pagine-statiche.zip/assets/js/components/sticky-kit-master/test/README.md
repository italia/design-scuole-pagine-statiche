
# `test`

This is the old manual test suite, see `spec` for the updated jasmine one. Once
all tests have been ported this directory will be removed.
